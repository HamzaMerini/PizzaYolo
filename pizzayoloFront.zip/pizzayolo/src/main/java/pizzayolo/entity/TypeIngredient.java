package pizzayolo.entity;

public enum TypeIngredient {
	Base,Ingredient
}
