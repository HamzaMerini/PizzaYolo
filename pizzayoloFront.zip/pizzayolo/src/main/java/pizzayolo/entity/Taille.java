package pizzayolo.entity;

public enum Taille {
	Medium,Large,XL;

}
