package pizzayolo.entity;

public class JsonViews {
	
	public static class Common {    
	}
}
