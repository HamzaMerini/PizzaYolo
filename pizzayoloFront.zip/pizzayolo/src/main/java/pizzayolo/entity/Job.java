package pizzayolo.entity;

public enum Job {
	Livreur,Cuisinier,Serveur
}
