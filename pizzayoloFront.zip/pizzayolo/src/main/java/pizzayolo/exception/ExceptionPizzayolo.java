package pizzayolo.exception;

public class ExceptionPizzayolo extends RuntimeException{

	public ExceptionPizzayolo() {
		// TODO Auto-generated constructor stub
	}

}
