package pizzayolo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pizzayolo.entity.Boisson;

public interface BoissonRepository extends JpaRepository<Boisson, Long>{

}
