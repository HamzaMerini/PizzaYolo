package pizzayolo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pizzayolo.entity.Employe;

public interface EmployeRepository extends JpaRepository<Employe, Long>{

}
