package pizzayolo.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import pizzayolo.entity.Creneau;

public interface CreneauRepository extends JpaRepository<Creneau, Long>{

}
